</main>
<!-- Wrapper End-->
<!-- Library Bundle Script -->
<script src="../assets/js/core/libs.min.js"></script>

<!-- External Library Bundle Script -->
<script src="../assets/js/core/external.min.js"></script>

<!-- Widgetchart Script -->
<script src="../assets/js/charts/widgetcharts.js"></script>

<!-- mapchart Script -->
<script src="../assets/js/charts/vectore-chart.js"></script>
<script src="../assets/js/charts/dashboard.js" ></script>

<!-- fslightbox Script -->
<script src="../assets/js/plugins/fslightbox.js"></script>

<!-- Settings Script -->
<script src="../assets/js/plugins/setting.js"></script>

<!-- Slider-tab Script -->
<script src="../assets/js/plugins/slider-tabs.js"></script>

<!-- Form Wizard Script -->
<script src="../assets/js/plugins/form-wizard.js"></script>

<!-- AOS Animation Plugin-->
<script src="../assets/vendor/aos/dist/aos.js"></script>

<!-- App Script -->
<script src="../assets/js/hope-ui.js" defer></script>
<script src="assetsadmin/js/applyBindings_Main.js" defer></script>

</body>
</html>
<?php /**PATH /media/ahmadf/248204B382048B8C/laravel serv/project/Test_Skill_Fullstack_Developer/resources/views/template/footsiginadnsigup.blade.php ENDPATH**/ ?>