<!--  fungsi logout ada di file :  -->
<script>
var material = {
  Recordmaterial: ko.mapping.fromJS(model.masterModel),
  Listmaterial: ko.observableArray([]),
  Mode: ko.observable(''),
}

material._logout = function () {
  var title = 'Keluar Aplikasi!';
  if (confirm(material.Recordmaterial.notif()+title) === true) {
    window.location.replace(material.Recordmaterial.logout());
  }
}

  // PARENT NAVBAR MENU 0 = MENU UTAMA
  model.selectsParentsMenu = function(){
    url = "/Controll_navbar/getDataMenu",
    ajaxPost(url, material.Recordmaterial, function (res) {
      $.each(res, function(i, item){ // looping data semua data
        var r = res[i];
        // console.log(r);

        if(res[i].menuparentid == 0) { // tangkap data parent menu (0)
          var r = res[i];
          console.log(r.menuname);

            $.each(res, function(i, item){ // looping data berdasarkan menuparentid selain 0
              if(res[i].menuparentid == 2){
                console.log(res[i].menuname); // print menuname
              }
            });

        }

        // material.Recordmaterial.selectJenisPakets(selectJenisPakets);
      });
    });
  }



</script>

<!--  sidebar -->

<!-- BEGIN: Main Menu-->
<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
  <div class="navbar-header">
    <ul class="nav navbar-nav flex-row">
      <li class="nav-item mr-auto"><a class="navbar-brand" href="#">
        <div class="brand-logo"><img class="logo" src="/assetsadmin/images/logo/logo.png" /></div>
        <h2 class="brand-text mb-0">Frest</h2>
      </a></li>
      <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"><i class="bx bx-x d-block d-xl-none font-medium-4 primary toggle-icon"></i><i class="toggle-icon bx bx-disc font-medium-4 d-none d-xl-block collapse-toggle-icon primary" data-ticon="bx-disc"></i></a></li>
    </ul>
  </div>
  <div class="shadow-bottom"></div>
  <div class="main-menu-content">
    <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation" data-icon-style="">

      <li class="nav-item">
        <a href="/">
          <i class="bx bx-home-alt"></i>
          <span class="menu-title" data-i18n="DASHBOARD">DASHBOARD</span>
        </a>
      </li>
      <li class="nav-item">
        <a href="/contacts">
          <i class="bx bx-home-alt"></i>
          <span class="menu-title" data-i18n="Contacts">Contacts List</span>
        </a>
      </li>
      <li class="nav-item">
        <a href="/book">
          <i class="bx bxs-book-open"></i>
          <span class="menu-title" data-i18n="book">Book List</span>
        </a>
      </li>

       


          <script>
          model.Model = {
            menuname:"",
          }
          var mat = {
            Record: ko.mapping.fromJS(model.Model),
            Listmaterial: ko.observableArray([]),
            Mode: ko.observable(''),
            FilterText: ko.observable(''),
          }

          // $.getJSON('http://localhost/smw_master/Controll_navbar/getDataParents', function(data) {
          //  $.each(data, function(i) {
          //    url = ''+data[i].menulink+'';
          //    menuicon  = data[i].menuicon;
          //    menuname  = data[i].menuname;
          //    menulink  = data[i].menulink;
          //    menualias = data[i].menualias;
          //    menuparentid = data[i].menuparentid;
          //
          //    // if(menuparentid == 0){
          //      $("#menu").append('<a href="'+url+'"><i class="bx '+menuicon+'"></i><span class="menu-title" data-i18n="Invoice">'+menuname+'</span></a>');
          //    // }
          //
          //  });
          // });

          // data childs menu
          // $.getJSON('http://localhost/smw_master/Controll_navbar/getDataChilds', function(c) {


            // $.getJSON('http://localhost/smw_master/Controll_navbar/getDataParents', function(p) {
            //    $.each(p, function(i) {
            //      if(p[i].menuparentid == 0){
            //        // console.log(p[i].menuname);
            //
            //
            //
            //      }
            //    });
            //
            // });

            $.getJSON('', function(c) {
              $.each(c, function(i) {
                // if(p[i].menuparentid==){

                for (i in c[i].res) {
                  x += "<h2>" + c[i].res[i].menuname + "</h2>";
                  console.log(x);
                }

                // }
              });

            });




          // }); // childs
          </script>
          <li class="nav-item" id="menu"></li>

          <li class="nav-item" id="menus">
            <!-- if child menu -->
            <ul class="menu-content" >
              <li id="childs">
              </li>
            <li>
          </li>


          <!-- HTML menu -->
          <!-- <li class="nav-item">
            <a href="#">
              <i class="bx bx-file"></i>
              <span class="menu-title" data-i18n="Invoice">Invoice</span>
            </a> -->
                    <!-- <ul class="menu-content">
                      <li>
                        <a href="app-invoice-list.html">
                          <i class="bx bx-right-arrow-alt"></i>
                          <span class="menu-item" data-i18n="Invoice List">Invoice List</span>
                        </a>
                      </li>
                    </ul> -->
          <!-- </li> -->
          <!-- ./ HTML menu -->


      <!--
      TASK - MENU WITH JAVA_SCRIPT

      api Parents = http://localhost/smw_master/Controll_navbar/getDataParents
      api childs  = http://localhost/smw_master/Controll_navbar/getDataChilds
      -->

      <!-- HTML menu -->
      <!-- <li class=" nav-item">
        <a href="#">
          <i class="bx bx-file"></i>
          <span class="menu-title" data-i18n="Invoice">Invoice</span>
        </a>
        <ul class="menu-content">
          <li>
            <a href="app-invoice-list.html">
              <i class="bx bx-right-arrow-alt"></i>
              <span class="menu-item" data-i18n="Invoice List">Invoice List</span>
            </a>
          </li>
        </ul>
      </li> -->
      <!-- ./ HTML menu -->




    </ul>
  </div>
</div>
<!-- END: Main Menu--><?php /**PATH /media/ahmadf/248204B382048B8C/laravel serv/project/master/resources/views/template/navbar-side.blade.php ENDPATH**/ ?>