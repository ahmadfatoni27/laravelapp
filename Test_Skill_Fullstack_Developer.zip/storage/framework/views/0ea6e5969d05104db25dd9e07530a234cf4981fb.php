 <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <!-- Page wrapper  -->
 <!-- ============================================================== -->
 <div class="app-content content">
  <div class="content-overlay"></div>
  <div class="content-wrapper">

    <!-- content -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- end content -->

  </div><!-- content-wrapper -->
</div><!-- app-content -->
<!-- footer -->
<?php echo $__env->make('template.footsiginadnsigup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /media/ahmadf/248204B382048B8C/laravel serv/project/Test_Skill_Fullstack_Developer/resources/views/siginadnsigup.blade.php ENDPATH**/ ?>