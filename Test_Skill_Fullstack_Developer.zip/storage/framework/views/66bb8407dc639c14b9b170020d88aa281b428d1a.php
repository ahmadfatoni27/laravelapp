    
    <?php $__env->startSection('content'); ?>
    i am a Compenies page.
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('defaultTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\serv7.4\xampp\htdocs\web_master_laravel\resources\views/companies/index.blade.php ENDPATH**/ ?>