<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<meta name="description" content="Frest admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
	<meta name="keywords" content="admin template, Frest admin template, dashboard template, flat admin template, responsive admin template, web app">
	<!-- <meta name="author" content="PIXINVENT"> -->
	<title>-</title>
	<link rel="apple-touch-icon" href="/assetsadmin/images/ico/favicon.ico">
	<link rel="shortcut icon" type="image/x-icon" href="/assetsadmin/images/ico/favicon.ico">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
	<!-- <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,600%7CIBM+Plex+Sans:300,400,500,600,700" rel="stylesheet"> -->

	<!-- CUSTOM STYLE -->
 

	<link rel="stylesheet" type="text/css" href="/assetsadmin/css/_custom.css">

 
	<!-- ./ CUSTOM -->

	<!-- animated -->
	<link rel="stylesheet" type="text/css" href="/assetsadmin/css/animate.min.css">

	<!-- BEGIN: Vendor CSS-->
	<link rel="stylesheet" type="text/css" href="/assetsadmin/vendors/css/vendors.min.css">
	<link rel="stylesheet" type="text/css" href="/assetsadmin/vendors/css/charts/apexcharts.css">
	<link rel="stylesheet" type="text/css" href="/assetsadmin/vendors/css/extensions/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="/assetsadmin/vendors/css/tables/datatable/datatables.min.css">
	<!-- END: Vendor CSS-->

	<!-- BEGIN: Theme CSS-->
	<link rel="stylesheet" type="text/css" href="/assetsadmin/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="/assetsadmin/css/bootstrap-extended.css">
	<link rel="stylesheet" type="text/css" href="/assetsadmin/css/colors.css">
	<link rel="stylesheet" type="text/css" href="/assetsadmin/css/components.css">

	<!-- END: Theme CSS-->
	<!-- BEGIN: Page CSS-->
	<link rel="stylesheet" type="text/css" href="/assetsadmin/css/core/menu/menu-types/vertical-menu.css">
	<!-- <link rel="stylesheet" type="text/css" href="/assetsadmin/css/pages/dashboard-ecommerce.css"> -->
	<!-- END: Page CSS-->

	<link rel="stylesheet" type="text/css" href="/assetsadmin/custom/style.css">

	<!-- alert -->
	<link href="/assetsadmin/alert/sweetalert.css" rel="stylesheet" type="text/css">
	<script src="/assetsadmin/alert/sweetalert.min.js"></script>

	<!-- apex charts css -->
	<link rel="stylesheet" type="text/css" href="/assetsadmin/vendors/css/charts/apexcharts.css">

	<!-- underscrore -->
	<script type="text/javascript" src= "/assetsadmin/js/underscore.js"></script>
	<!-- jquery -->
	<script src="/assetsadmin/js/jquery.min.js"></script>
	<script src="/assetsadmin/js/jquery_v3.6.0.min.js"></script>
	<script src="/assetsadmin/js/jquery.serializejson.js"></script>

	<!-- knockout -->
	<script src="/assetsadmin/knockout/knockout-3.1.0.js"></script>
	<script src="/assetsadmin/knockout/knockout.mapping-latest.js"></script>
	<script src="/assetsadmin/knockout/knockout-file-bindings.js"></script>
	<link href="/assetsadmin/knockout/knockout-file-bindings.css">

	<!-- token input -->
	<link href="/assetsadmin/token_input/token-input.css" rel="stylesheet">
	<link href="/assetsadmin/token_input/token-input-facebook.css" rel="stylesheet">
	<script src="/assetsadmin/token_input/jquery.tokeninput.js"></script>

	<!-- moment js for date format -->
	<script src="/assetsadmin/js/moment.min.js"></script>

	<!-- croppie => croping images -->
	<link href="/assetsadmin/croppie/croppie.css" rel="stylesheet" >
	<script src="/assetsadmin/croppie/croppie.js" type="text/javascript"></script>

	<!-- notify -->
	<link rel="stylesheet" type="text/css" href="/assetsadmin/notify/notify.css">
	<script src="/assetsadmin/notify/notify.js"></script>

	<script>

		var model = {
			Processing: ko.observable(true),
			ProcessingContent: ko.observable(false),
			checkPass: ko.observable(false),
			CheckId: ko.observable(false),
			changeRupiah: ko.observable(''),
			URI_PAGE: 4, // setup uri access on pages.
			CheckValue: ko.observable(true),
			giftWrap: ko.observable(true),
		}

		model.changeRupiah = function(value) {
			var	number_string = value.toString(),
			sisa 		= number_string.length % 3,
			rupiah 	= number_string.substr(0, sisa),
			ribuan 	= number_string.substr(sisa).match(/\d{3}/g);
			if (ribuan) {
				separator = sisa ? '.' : '';
				rupiah += separator + ribuan.join('.');
				rupiah = 'Rp '+rupiah;
			} return rupiah;
		// Cetak hasil
		// document.write(rupiah); // Hasil: r23.456.789
	}
</script>
</head>

<!-- BEGIN: Body-->
<body class="vertical-layout vertical-menu-modern 2-columns  navbar-sticky footer-static  " data-open="click" data-menu="vertical-menu-modern" data-col="2-columns">

	<!-- ============================================================== -->
	<!-- Preloader - style you can find in spinners.css -->
	<!-- ============================================================== -->
	<div class="preloader" style="background-color: white; opacity: 0.9;" data-bind='visible: model.Processing()==true' >
		<div class="loading text-center" >
			<span class="spinner-border spinner-border-lg" role="status" aria-hidden="true"></span>
		</div>
	</div>

	<!-- ============================================================== -->
	<!-- Main wrapper - style you can find in pages.scss -->
	<!-- ============================================================== -->

	<script>
		model.Resource = {
			logout: 'url-logout', /* isikan value dari rootingnya  (url dengan uri = 1)*/
			notif: 'Anda yakin? Anda Akan ',
		}
	</script>


	
<?php /**PATH /media/ahmadf/248204B382048B8C/laravel serv/project/master/resources/views/template/head.blade.php ENDPATH**/ ?>