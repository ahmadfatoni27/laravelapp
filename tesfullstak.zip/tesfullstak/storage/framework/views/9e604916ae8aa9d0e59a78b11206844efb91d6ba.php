 <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <!--  sidebar Top bar -->
 <?php echo $__env->make('template.navbar-side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->make('template.navbar-top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <!-- Page wrapper  -->
 <!-- ============================================================== -->
 <div class="app-content content">
  <div class="content-overlay"></div>
  <div class="content-wrapper">

    <!-- content -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- end content -->

  </div><!-- content-wrapper -->
</div><!-- app-content -->
<!-- footer -->
<?php echo $__env->make('template.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel serv\project\web_master_laravel\resources\views/defaultTemplate.blade.php ENDPATH**/ ?>