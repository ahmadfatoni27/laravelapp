<!-- BEGIN: Footer-->
<footer class="footer footer-static footer-light">
	<p class="clearfix mb-0"><span class="float-left d-inline-block">2020 &copy; PIXINVENT</span>
		<span class="float-right d-sm-inline-block d-none">Crafted with<i class="bx bxs-heart pink mx-50 font-small-3"></i>by<a class="text-uppercase"
			href="" target="_blank">Pixinvent</a></span>
			<button class="btn btn-primary btn-icon scroll-top marg-right" type="button"><i class="bx bx-up-arrow-alt"></i></button>
		</p>
	</footer>

	<!-- <script src="http://localhost:8088/template_premium/frest-html-bootstrap-admin-template/app-assets/vendors/js/extensions/idle-timer.min.js"></script> -->

	<!-- END: Footer-->
	<!-- ___________________ -->
	<!-- BEGIN: Vendor JS-->
	<script src="/assetsadmin/vendors/js/vendors.min.js"></script>
	<script src="/assetsadmin/fonts/LivIconsEvo/js/LivIconsEvo.tools.js"></script>
	<script src="/assetsadmin/fonts/LivIconsEvo/js/LivIconsEvo.defaults.js"></script>
	<script src="/assetsadmin/fonts/LivIconsEvo/js/LivIconsEvo.min.js"></script>
	<!-- BEGIN Vendor JS-->

	<!-- toast -->
	<link rel="stylesheet" type="text/css" href="/assetsadmin/vendors/css/extensions/toastr.css"/>
	<link rel="stylesheet" type="text/css" href="/assetsadmin/css/plugins/extensions/toastr.css"/>
	<script src="/assetsadmin/js/scripts/extensions/toastr.js" ></script>
	<script src="/assetsadmin/vendors/js/extensions/toastr.min.js" ></script>

	<!-- BEGIN: Page Vendor JS-->
	<script src="/assetsadmin/vendors/js/charts/apexcharts.min.js"></script>
	<script src="/assetsadmin/vendors/js/extensions/swiper.min.js"></script>

	<script src="/assetsadmin/vendors/js/tables/datatable/datatables.min.js"></script>
	<script src="/assetsadmin/vendors/js/tables/datatable/dataTables.bootstrap4.min.js"></script>
	<script src="/assetsadmin/vendors/js/tables/datatable/dataTables.buttons.min.js"></script>
	<script src="/assetsadmin/vendors/js/tables/datatable/buttons.html5.min.js"></script>
	<script src="/assetsadmin/vendors/js/tables/datatable/buttons.print.min.js"></script>
	<script src="/assetsadmin/vendors/js/tables/datatable/buttons.bootstrap.min.js"></script>
	<script src="/assetsadmin/vendors/js/tables/datatable/pdfmake.min.js"></script>
	<script src="/assetsadmin/vendors/js/tables/datatable/vfs_fonts.js"></script>
	<!-- END: Page Vendor JS-->

	<!-- BEGIN: Theme JS-->
	<script src="/assetsadmin/js/scripts/configs/vertical-menu-light.js"></script>
	<script src="/assetsadmin/js/core/app-menu.js"></script>
	<script src="/assetsadmin/js/core/app.js"></script>
	<script src="/assetsadmin/js/scripts/components.js"></script>
	<script src="/assetsadmin/js/scripts/footer.js"></script>
	<!-- END: Theme JS-->

	<!-- BEGIN: Page Vendor JS-->
	<script src="/assetsadmin/vendors/js/charts/chart.min.js"></script>
	<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.min.js" ></script> -->
	<script src="/assetsadmin/vendors/js/charts/apexcharts.min.js"></script>
	<!-- END: Page Vendor JS-->

	<!-- BEGIN: Page JS-->
	<!-- END: Page JS-->

	<!-- icheck -->
	<script src="/assetsadmin/plugins/icheck/icheck.min.js"></script>
	<script src="/assetsadmin/plugins/icheck/icheck.init.js"></script>
	<!-- pemisah titik -->
	<script src="/assetsadmin/js/pemisahTitik.js"></script>
	<!-- This is data table -->

	<!-- ============================================================== -->
	<!-- Style switcher -->
	<!-- ============================================================== -->

	<!-- BEGIN: Page JS-->
	<script src="/assetsadmin/js/scripts/navs/navs.js"></script>
	<script src="/assetsadmin/js/scripts/datatables/datatable.js"></script>
	<!-- END: Page JS-->
	<!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAzDEepTI6qMIoZ3OGMe03ZWpmrIakZCwc&callback"></script> -->

	<script src="/assetsadmin/js/applyBindings_Main.js" type="text/javascript"></script>

</body>
<!-- END: Body-->

</html>
<?php /**PATH G:\laravel serv\project\web_master_laravel\resources\views/template/foot.blade.php ENDPATH**/ ?>