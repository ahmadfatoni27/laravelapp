<?php $__env->startSection('content'); ?>
<script>
	model.masterModel = {
		id: "",
		NAME: "",
		HP: "",
		EMAIL: "",
		ADDRESS: "",
		MODE: "",
		IDWILAYAH:"",
		SELECTFILTERVALUE: [{ name: 'NAME', value: 'NAME'},{name: 'ADDRESS', value: 'ADDRESS'}],
	}
	model.VMfilterAlamat = {
		CONCAT: "",
		IDWILAYAH:"",
	}
	var material = {
		url_dir: ko.observable('/contacts'),  /* location of Controller file */
		Recordmaterial: ko.mapping.fromJS(model.masterModel),
		RecordfilterAlamat: ko.mapping.fromJS(model.VMfilterAlamat),
		Listmaterial: ko.observableArray([]),
		Mode: ko.observable(''),
		CREATEBY: ko.observable('CREATEBY'),
		FilterText: ko.observable(""),
		DataFilter: ko.observableArray(['NAME']),
		FilterValue: ko.observable("NAME"),
	}
	material.back = function(tab){
		material.Mode('');
		material.grid.ajax.reload( null, true );

		$("input[name='txtADDRESS']").tokenInput('clear');
		$("input[name='txtADDRESS']").tokenInput('destroy');
		material.drawAlamat();
		ko.mapping.fromJS(model.masterModel, material.Recordmaterial);
		model.activetab(tab);
	}
	/* TOKEN INPUT */
	material.drawAlamat = function() {
		$("input[name=txtADDRESS]").tokenInput(material.url_dir()+"/filterAlamat", {
			zindex: 700,
			allowFreeTagging: false,
			placeholder: 'Search by addres name..!',
			tokenValue: 'IDWILAYAH',
			propertyToSearch: "CONCAT",
			tokenLimit: 1,
			theme: "facebook",
			onAdd: function (item) {
				var po = material.RecordfilterAlamat;
				var Record = material.Recordmaterial;

				po.IDWILAYAH(item.IDWILAYAH);
				po.CONCAT(item.CONCAT);

				Record.ADDRESS(po.CONCAT());
				Record.IDWILAYAH(po.IDWILAYAH());
			},
			onDelete: function(item) {
				var po = material.RecordfilterAlamat;
				po.IDWILAYAH("");
				po.CONCAT("");
			},
			resultsFormatter: function(item) {
				return "<li>"+item.CONCAT+"</li>"
			},
			onResult: function (results) {
				return results;
			},
			onCachedResult: function(res) {
				return res;
			}
		});
	}
	material.selectdata = function(id) {
		material.back(0);
		model.Processing(true);
		material.Mode("Update");
		var id = material.Recordmaterial.id(id);
		var url = material.url_dir()+"/show/edit";
		$.ajax({
			url: url,
			type: 'GET',
			data : {id: id},
			success : function(res) {
				console.log(res);
				ko.mapping.fromJS(res[0], material.Recordmaterial);
				ko.mapping.fromJS(res[0], material.RecordfilterAlamat);

				var itemSelect = {
					IDWILAYAH: res[0].IDWILAYAH,
					CONCAT: res[0].CONCAT,
				}
				$("input[name=txtADDRESS]").tokenInput("add", itemSelect);

				$("input[name=txtid]").attr("disabled", true);
				model.Processing(false);
			}
		});
	}

	material.save = function(){
		model.Processing(true);
		var val = material.Recordmaterial;
		val.MODE(material.Mode());
		swal({
			title: "Konfirmasi",
			text: "Apakah data sudah benar??",
			type: "info",
			showCancelButton: true, /* button cancel*/
			closeOnConfirm: false,
			showLoaderOnConfirm: true, /* button Yes*/
		}, function () {
			setTimeout(function(){
				swal({ title: "Good job!",
					text: "Operasi di terima!",
					icon: "success", /* sukses simpan / update */
				});
			}, 2000);
			if (showLoaderOnConfirm=true) {
				var url = material.url_dir()+"/show/update"; // insert && update
				$.ajax({
					url: url,
   					method: 'PUT', // method: 'post' //GET, HEAD, PUT, PATCH, DELETE."
   					data : val,
   					success : function(res) {
   						var res = JSON.parse(res);
   						console.log(res);
   						res = res.result;
   						if (res == "Inserted" || res == "Updated") {
   							material.back(1);
							// swal(res+"!", res, "success");
						}
						model.Processing(false); /* end proses simpan / update*/
					}
				});
			}
		});
		model.Processing(false); /* for process cancel button  */
	}

	material.remove = function(id){
	// model.Processing(true);
	swal({
		title: "Are you sure?",
		text: "Delete this data !"+id,
		type: "warning",
		showCancelButton: true,
		confirmButtonColor: "#DD6B55",
		confirmButtonText: "Yes!",
		cancelButtonText: "No!",
		closeOnConfirm: false,
	}, function(isConfirm){
		if (isConfirm) {
			$.ajax({
				url: material.url_dir()+"/delete",
   					method: 'DELETE', // it should be method: 'post' //GET, HEAD, PUT, PATCH, DELETE."
   					data : {id : id},
   					success : function(res) {
   						var res = JSON.parse(res);
   						console.log(res);
   						if (res.result == "OK") {
   							material.back(1);
   							swal("Deleted!", "Deleted", "success");
   						}
   						model.Processing(false); /* end proses simpan / update*/
   					}
   				});

		} // model.Processing(false);
	});
}

</script>


<!-- BEGIN: Content-->
<div class="content-header row">
	<div class="content-header-left col-12 mb-2 mt-1">
		<div class="row breadcrumbs-top">
			<div class="col-12">
				<h5 class="content-header-title float-left pr-1 mb-0">
					-
				</h5>
				<div class="breadcrumb-wrapper col-12">
					<ol class="breadcrumb p-0 mb-0">
						<li class="breadcrumb-item">
							<a href="/Admin">
								<i class="bx bx-home-alt"></i>
							</a>
						</li>
						<li class="breadcrumb-item active">
							-
						</li>
					</ol>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="content-body">
	<!-- Basic tabs start -->

	<section id="basic-tabs-components">
		<div class="card">
			<!-- <div class="card-header">
			<div class="card-title">
			<h4>Basic Tab</h4>
		</div>
	</div> -->

	<div class="card-content">
		<div class="card-body" data-bind="with:material">

			<!-- <p>Takes the basic nav from above and adds the <code>.nav-tabs</code> class to generate a tabbed interface.</p> -->
			<ul class="nav nav-tabs customtab" id="tabnavform">

				<li class="nav-item">
					<a class="nav-link active" id="form-tab" data-toggle="tab" href="#tabform" aria-controls="form" role="tab" aria-selected="false">
						<i class="bx bx-save align-middle"></i>
						<span class="align-middle">FORM</span>
					</a>
				</li>

				<li class="nav-item">
					<a class="nav-link text-center" id="listdata-tab" data-toggle="tab" href="#tablist" aria-controls="listdata" role="tab" aria-selected="true">
						<i class="bx bx-detail align-middle"></i>
						<span class="align-middle">LIST</span>
					</a>
				</li>

			</ul>

			<div class="tab-content" id="tabnavform-content">

				<!--  ./ end tab form add / update data -->
				<div class="tab-pane active animated fadeIn" id="tabform"  aria-labelledby="form-tab" role="tabform">
					<div class="row p-t-23 margMin" >
						<div class="col-md-12 margMin">
							<div class="form-group ">

								<button data-bind="click:function(){back(1);}, visible: material.Mode() == 'Update'" data-toggle="tooltip" data-placement="top" data-original-title="Kembali" class="btn btn-sm btn-outline-warning mr-1 mb-1" >
									<i class="bx bx-share"></i>
								</button>

								<button data-bind="
								click:save, 
								data-original-title:Mode" 
								data-toggle="tooltip" 
								data-placement="top" 
								data-original-title="simpan" 
								class="btn btn-icon btn-outline-success mr-1 mb-1">
								<i class="bx bx-save"></i> Save
							</button>
							<button data-bind="
							click:function(){remove(Recordmaterial.id());}, visible: material.Mode() == 'Update'" 
							class="btn btn-icon btn-outline-danger mr-1 mb-1">
							<i class="bx bx-trash"></i>
						</button>
						<button data-bind="
						visible: material.Mode() == 'Update'" type="button" class="btn btn-icon btn-light mr-1 mb-1">
						no : <i class="bx" data-bind="
						text: Recordmaterial.id()"></i>
					</button>

				</div>
			</div>
		</div>

		<!-- FORM -->

		<div class="form form-vertical" >
			<div class="form-body">

				<div class="row" data-bind="with:Recordmaterial" >
					<!-- ko if: material.Mode()=='' -->
					<div class="col-md-4 col-12">
						<div class="form-group">
							<label for="first-name-vertical">ID</label>
							<input type="text" name="txtid" data-bind="value: id, checkId: 'contacts/checkId'" id="invalid-state" required="" class="form-control ">
							<div class="invalid-feedback" data-bind="visible: model.CheckId()==='false'">
								<i class="bx bx-radio-circle"></i>
								Data Sama
							</div>
						</div>
					</div>
					<div class="col-md-8 col-12"></div>
					<!-- /ko -->

					<div class="col-md-6 col-12">
						<div class="form-group">
							<label for="first-name-vertical">NAME</label>
							<input type="text" name="txtNAME" data-bind="value: NAME" id="" required="" class="form-control">
						</div>
					</div>

					<div class="col-md-6 col-12">
						<div class="form-group">
							<label for="first-name-vertical">HP</label>
							<input type="number" name="txtHP" data-bind="value: HP" id="" required="" class="form-control">
						</div>
					</div>

					<div class="col-md-6 col-12">
						<div class="form-group">
							<label for="first-name-vertical">EMAIL</label>
							<input type="text" name="txtEMAIL" data-bind="value: EMAIL" id="" required="" class="form-control">
						</div>
					</div>

					<div class="col-md-6 col-12">
						<label for="first-name-vertical">ADDRESS</label>
						<div class="form-group">
							<input type="text" name="txtADDRESS" required="" class="form-control">
						</div>
					</div>

				</div>
			</div>
		</div>
		<!-- ./ END FORM -->
	</div>
	<!--  ./ end tab form add / update data -->

	<!-- list data -->
	<div class="tab-pane" id="tablist" aria-labelledby="listdata-tab" role="tabpanel">
		<!-- Zero configuration table -->
		<section id="basic-datatable" >

			<div class="row" data-bind="with: material">
				<!-- filter -->
				<div class="col-sm-3 col-md-3 margFilter">
					<fieldset class="form-group">
						<select name="" data-bind="
						options: Recordmaterial.SELECTFILTERVALUE(),
						optionsText: 'name',
						optionsValue: 'value',
						value:FilterValue"
						class="form-control" id="basicSelect">
					</select>
				</fieldset>
			</div>
			<div class="col-sm-3 col-md-3 margFilter">
				<div class="form-group ">
					<input data-bind="value:FilterText" id="" placeholder="Filter by data" class="form-control">
				</div>
			</div>
			<div class="col-sm-3 col-md-3 margFilter">
				<div class="form-group ">
					<button class="btn btn-md btn-danger" data-bind="click:filterreset"><span class="bx bx-block"></span></button>
					<button class="btn btn-md btn-primary" data-bind="click:filtermaterial"><span class="bx bx-search"></span></button>
				</div>
			</div>
			<!-- ./filter -->
			<div class="col-12">
				<div class="table-responsive animated fadeIn" >
					<table id="myTable" width="100%" class="table table-striped zero-configuration">
						<thead>
							<tr>
								<th >NAME</th>
								<th >HP</th>
								<th >EMAIL</th>
								<th >ADDRESS</th>
								<th >ACTION</th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
		</div>
	</section>
	<!--/ Zero configuration table -->
</div>
<!-- ./ end list data  -->
</div>
</div>
</div>
</div>
</section>
<!-- Basic Tag Input end -->

</div><!-- content-body -->

<script>
	material.filtermaterial = function() {
		material.grid.ajax.reload();
	}
	material.filterreset = function() {
		material.FilterText('');
		material.grid.ajax.reload();
	}

	material.checkAksesHalaman = function(){
		var URL = document.URL;
		var arr=URL.split('/'); //arr[0]='http' //arr[1]='' //arr[2]='name projek' //arr[3]='name of page'
		var id=arr[4]; //uri='10';
		$.ajax({
			url: "/Admin/getDataUriPage",
			type: 'post', dataType: 'json', data : {id: id},
			success : function(res) {
				var check = res.result;
				if(check!="200") {
					window.location.replace("/Auth/logout");
				}
			}
		});
	}
	$(document).ready(function(){
		material.checkAksesHalaman();
		material.drawAlamat();
		material.grid = $("#myTable").DataTable({
			"processing": true,
			"serverSide": true,
			"ordering": false,
			"bLengthChange": false,
			"bInfo": true,
			"ajax": {
				"url": material.url_dir()+"/show",
				"type": "POST",
				"data": function(d){
					d['filtervalue'] = material.FilterValue();
					d['filtertext'] = material.FilterText();
					return d;
				},
				"dataSrc": function (json) {
				// json.draw = 1;
				json.recordsTotal = json.RecordsTotal;
				json.recordsFiltered = json.RecordsFiltered;

				if (json.Data)
					return json.Data;
				else
					return [];
			},
		},
		"searching": false,
		"columns": [
		{"data": "NAME"},
		{"data": "HP"},
		{"data": "EMAIL"},
		{"data": "ADDRESS"},
		{
			"data": "id",
			"render": function( data, type, full, meta){
				return "<button class='btn btn-icon btn-info' onClick='material.selectdata(\""+data+"\")'><i class='bx bx-pencil'></i></button> &nbsp; <button  id='sa-warning' class='btn btn-icon btn-danger' onClick='material.remove(\""+data+"\")' id='sa-warning' ><i class='bx bx-trash'></i></button>";
			}
		}
		],
	});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('defaultTemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\serv7.4\xampp\htdocs\web_master_laravel\resources\views/contact/index.blade.php ENDPATH**/ ?>